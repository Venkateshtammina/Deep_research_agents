from langgraph.graph import StateGraph, END
from agents.research_agent import research_agent
from agents.drafting_agent import drafting_agent

def create_research_graph():
    # Define the state schema
    class ResearchState(dict):
        pass

    workflow = StateGraph(ResearchState)

    # Nodes
    workflow.add_node("research_agent", research_agent)
    workflow.add_node("drafting_agent", drafting_agent)

    # Edges - defining the flow
    workflow.add_edge("research_agent", "drafting_agent")
    workflow.add_edge("drafting_agent", END)

    workflow.set_entry_point("research_agent")

    return workflow.compile()
