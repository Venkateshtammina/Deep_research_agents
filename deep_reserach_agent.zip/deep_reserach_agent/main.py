from graph import create_research_graph
from langgraph.graph import StateGraph
from langchain.schema import SystemMessage

def main():
    query = input("Enter your research query: ")

    # Build the agentic workflow graph
    graph = create_research_graph()

    # Run the graph flow with user query as input
    inputs = {"query": query}
    result = graph.invoke(inputs)

    print("\n--- Final Research Report ---\n")
    print(result['final_report'])

if __name__ == "__main__":
    main()
