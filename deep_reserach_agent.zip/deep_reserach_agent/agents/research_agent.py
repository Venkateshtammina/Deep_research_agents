import os
from tavily import TavilyClient
from utils.preprocess import clean_html

# Initialize Tavily client
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")
tavily_client = TavilyClient(api_key=TAVILY_API_KEY)

def research_agent(state):
    query = state.get("query")

    # Search using Tavily
    search_results = tavily_client.search(query, search_depth="basic", max_results=5)

    # Extract and clean content from search results
    collected_data = []
    for result in search_results["results"]:
        url = result["url"]
        content = clean_html(result["content"])  # Clean HTML into plain text
        collected_data.append(f"Source: {url}\nContent:\n{content}\n")

    state["collected_data"] = "\n".join(collected_data)

    return state
