from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate

llm = ChatOpenAI(model="gpt-4", temperature=0)

def drafting_agent(state):
    collected_data = state["collected_data"]
    query = state["query"]

    # Prompt to draft the final report
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a research assistant tasked with summarizing information into a clear, structured research report."),
        ("user", "Research Query: {query}\n\nCollected Data:\n{collected_data}\n\nWrite a comprehensive research summary addressing the query.")
    ])

    chain = prompt | llm

    response = chain.invoke({"query": query, "collected_data": collected_data})

    state["final_report"] = response.content
    return state
